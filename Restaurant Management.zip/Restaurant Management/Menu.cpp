#include "Menu.h"
#include <iostream>

Menu::Menu() {}

void Menu::addItem(const MenuItem& item) {
    items[item.getCategory()].push_back(item);
}

void Menu::removeItem(int itemId) {
    for (auto& category : items) {
        auto& itemList = category.second;
        itemList.erase(
            std::remove_if(itemList.begin(), itemList.end(),
                [itemId](const MenuItem& item) { return item.getId() == itemId; }),
            itemList.end());
    }
}

std::vector<MenuItem> Menu::getItemsByCategory(MenuCategory category) const {
    auto it = items.find(category);
    if (it != items.end()) {
        return it->second;
    }
    return std::vector<MenuItem>();
}

MenuItem* Menu::findItem(int itemId) {
    for (auto& category : items) {
        for (auto& item : category.second) {
            if (item.getId() == itemId) {
                return &item;
            }
        }
    }
    return nullptr;
}

void Menu::displayMenu() const {
    std::cout << "=== MEXICAN RESTAURANT MENU ===" << std::endl;
    for (const auto& category : items) {
        displayCategoryItems(category.first);
        std::cout << "\n";
    }
}

void Menu::displayCategoryItems(MenuCategory category) const {
    std::string categoryName;
    switch (category) {
        case MenuCategory::CHIMICHANGA: categoryName = "CHIMICHANGAS"; break;
        case MenuCategory::BURRITO: categoryName = "BURRITOS"; break;
        case MenuCategory::POLLO: categoryName = "POLLO (CHICKEN)"; break;
        case MenuCategory::CARNE: categoryName = "CARNE (MEAT)"; break;
        case MenuCategory::ENCHILADAS: categoryName = "ENCHILADAS"; break;
        case MenuCategory::TACOS: categoryName = "TACOS"; break;
        case MenuCategory::KIDS_MENU: categoryName = "KIDS MENU"; break;
        case MenuCategory::DRINKS: categoryName = "DRINKS"; break;
    }
    
    std::cout << "\n=== " << categoryName << " ===" << std::endl;
    auto it = items.find(category);
    if (it != items.end()) {
        for (const auto& item : it->second) {
            item.display();
        }
    }
}
