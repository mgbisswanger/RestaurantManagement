#ifndef ORDER_H
#define ORDER_H

#include <vector>
#include "MenuItem.h"

struct OrderItem {
    MenuItem item;
    int quantity;
    std::vector<std::string> modifications;
};

class Order {
private:
    int orderId;
    int tableId;
    std::vector<OrderItem> items;
    double subtotal;
    double tax;
    double tip;
    bool isPaid;

public:
    Order(int orderId, int tableId);
    void addItem(const MenuItem& item, int quantity);
    void removeItem(int itemId);
    void addModification(int itemId, const std::string& mod);
    void calculateBill(double taxRate = 0.08);
    void applyTip(double tipPercentage);
    void splitBill(int numPeople);
    void printReceipt() const;
    bool getPaymentStatus() const { return isPaid; }
    void markAsPaid() { isPaid = true; }
};

#endif
