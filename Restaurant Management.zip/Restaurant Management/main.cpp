#include "Menu.h"
#include "Table.h"
#include "Order.h"
#include "MenuItem.h"
#include <iostream>

int main() {
    // Initialize menu items
    Menu menu;
    menu.addItem(MenuItem(1, "Classic Chimichanga", 12.99, "Deep-fried burrito with your choice of filling", MenuCategory::CHIMICHANGA));
    menu.addItem(MenuItem(2, "Bean Burrito", 10.99, "Large flour tortilla filled with beans and cheese", MenuCategory::BURRITO));
    menu.addItem(MenuItem(3, "Pollo Asado", 15.99, "Grilled chicken with Mexican spices", MenuCategory::POLLO));
    menu.addItem(MenuItem(4, "Carne Asada", 17.99, "Grilled steak with peppers and onions", MenuCategory::CARNE));
    
    // Create tables
    std::vector<Table> tables;
    for(int i = 1; i <= 10; i++) {
        tables.push_back(Table(i, TableStatus::AVAILABLE));
    }
    
    std::cout << "=== Mexican Restaurant Management System ===" << std::endl;
    menu.displayAll();
    
    return 0;
}
