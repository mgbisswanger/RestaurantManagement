
#include "Table.h"

Table::Table(int id, int cap){
    tableId = (id), 
    capacity = cap ; 
    status = TableStatus::AVAILABLE; 
    //currentOrderId = -1;

} 
   // : tableId(id), capacity(cap), status(TableStatus::AVAILABLE), currentOrderId(-1) {}
