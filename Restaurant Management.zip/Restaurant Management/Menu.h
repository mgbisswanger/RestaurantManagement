#ifndef MENU_H
#define MENU_H

#include <vector>
#include <map>
#include "MenuItem.h"

class Menu {
private:
    std::map<MenuCategory, std::vector<MenuItem>> items;

public:
    Menu();
    void addItem(const MenuItem& item);
    void removeItem(int itemId);
    std::vector<MenuItem> getItemsByCategory(MenuCategory category) const;
    MenuItem* findItem(int itemId);
    void displayMenu() const;
    void displayCategoryItems(MenuCategory category) const;
};

#endif
