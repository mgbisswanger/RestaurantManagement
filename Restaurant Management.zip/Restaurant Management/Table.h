#include <iostream>
#include "Order.h"

enum TableStatus { AVAILABLE, OCCUPIED };

class Table {
public:
    Table(TableStatus status) : status(status) {}
    Table(int id, int cap, TableStatus status = AVAILABLE);

    bool isAvailable() const { return status == AVAILABLE; }

private:
    TableStatus status;
    Order order;
};

int main() {
    Table table1(TableStatus::AVAILABLE);
    Table table2(TableStatus::OCCUPIED);

    std::cout << "Table 1 is available: " << table1.isAvailable() << std::endl;
    std::cout << "Table 2 is available: " << table2.isAvailable() << std::endl;
    return 0;
}
