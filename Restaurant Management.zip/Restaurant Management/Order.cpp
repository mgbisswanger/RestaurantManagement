#include "Order.h"
#include <iomanip>
#include <iostream>

Order::Order(int orderId, int tableId) 
    : orderId(orderId), tableId(tableId), subtotal(0), tax(0), tip(0), isPaid(false) {}

void Order::addItem(const MenuItem& item, int quantity) {
    OrderItem newItem{item, quantity, std::vector<std::string>()};
    items.push_back(newItem);
}

void Order::removeItem(int itemId) {
    items.erase(
        std::remove_if(items.begin(), items.end(),
            [itemId](const OrderItem& orderItem) { 
                return orderItem.item.getId() == itemId; 
            }),
        items.end());
}

void Order::addModification(int itemId, const std::string& mod) {
    for (auto& orderItem : items) {
        if (orderItem.item.getId() == itemId) {
            orderItem.modifications.push_back(mod);
            break;
        }
    }
}

void Order::calculateBill(double taxRate) {
    subtotal = 0;
    for (const auto& item : items) {
        subtotal += item.item.getPrice() * item.quantity;
    }
    tax = subtotal * taxRate;
}

void Order::applyTip(double tipPercentage) {
    tip = subtotal * (tipPercentage / 100.0);
}

void Order::splitBill(int numPeople) {
    if (numPeople <= 0) return;
    double totalPerPerson = (subtotal + tax + tip) / numPeople;
    std::cout << "Amount per person: $" << std::fixed << std::setprecision(2) 
              << totalPerPerson << std::endl;
}

void Order::printReceipt() const {
    std::cout << "\n=== RECEIPT ===" << std::endl;
    std::cout << "Order #" << orderId << " - Table #" << tableId << std::endl;
    std::cout << std::fixed << std::setprecision(2);
    
    for (const auto& item : items) {
        std::cout << item.quantity << "x " << item.item.getName() 
                 << " - $" << (item.item.getPrice() * item.quantity) << std::endl;
        for (const auto& mod : item.modifications) {
            std::cout << "   * " << mod << std::endl;
        }
    }
    
    std::cout << "\nSubtotal: $" << subtotal << std::endl;
    std::cout << "Tax: $" << tax << std::endl;
    std::cout << "Tip: $" << tip << std::endl;
    std::cout << "Total: $" << (subtotal + tax + tip) << std::endl;
}
