#include "MenuItem.h"
#include <iomanip>
#include <iostream>


MenuItem::MenuItem(int id, const std::string& name, double price, const std::string& desc, MenuCategory cat)
    : itemId(id), itemName(name), itemPrice(price), description(desc), category(cat) {}

void MenuItem::display() const {
    std::cout << std::setw(4) << itemId << ". " 
              << std::setw(20) << std::left << itemName 
              << " $" << std::fixed << std::setprecision(2) << itemPrice << std::endl
              << "   " << description << std::endl;
}

int MenuItem::getId() const { return itemId; }
std::string MenuItem::getName() const { return itemName; }
double MenuItem::getPrice() const { return itemPrice; }
std::string MenuItem::getDescription() const { return description; }
MenuCategory MenuItem::getCategory() const { return category; }
