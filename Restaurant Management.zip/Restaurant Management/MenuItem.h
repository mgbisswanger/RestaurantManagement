#ifndef MENUITEM_H
#define MENUITEM_H

#include <string>
#include <iostream>

enum MenuCategory {
    CHIMICHANGA,
    BURRITO,
    POLLO,
    CARNE,
    ENCHILADAS,
    TACOS,
    KIDS_MENU,
    DRINKS
};

class MenuItem {
private:
    int itemId;
    std::string itemName;
    double itemPrice;
    std::string description;
    MenuCategory category;

public:
    MenuItem(int id, const std::string& name, double price, const std::string& desc, MenuCategory cat);
    void display() const;
    int getId() const;
    std::string getName() const;
    double getPrice() const;
    std::string getDescription() const;
    MenuCategory getCategory() const;
};

#endif
